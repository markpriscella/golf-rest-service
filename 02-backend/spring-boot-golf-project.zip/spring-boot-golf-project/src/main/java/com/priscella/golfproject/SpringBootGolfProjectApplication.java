package com.priscella.golfproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootGolfProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootGolfProjectApplication.class, args);
	}

}
