package com.priscella.golfproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootGolfProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
